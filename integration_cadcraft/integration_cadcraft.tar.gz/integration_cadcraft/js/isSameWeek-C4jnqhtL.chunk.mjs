import{n as c,s as t}from"./index-DQleZoUr.chunk.mjs";function e(o,i,n){const[r,s]=c(n?.in,o,i);return+t(r,n)==+t(s,n)}export{e as i};
//# sourceMappingURL=isSameWeek-C4jnqhtL.chunk.mjs.map
