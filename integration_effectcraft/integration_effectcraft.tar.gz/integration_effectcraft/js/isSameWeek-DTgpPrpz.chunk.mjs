import{n as a,s as t}from"./index-H8IMbPGg.chunk.mjs";function f(o,i,n){const[r,s]=a(n?.in,o,i);return+t(r,n)==+t(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-DTgpPrpz.chunk.mjs.map
