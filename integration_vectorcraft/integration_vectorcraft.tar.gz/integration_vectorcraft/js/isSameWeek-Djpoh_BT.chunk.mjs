import{n as a,s as t}from"./index-CwcN9peo.chunk.mjs";function f(o,r,n){const[i,s]=a(n?.in,o,r);return+t(i,n)==+t(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-Djpoh_BT.chunk.mjs.map
