const r={lastWeek:"eeee 'dernier à' p",yesterday:"'hier à' p",today:"'aujourd’hui à' p",tomorrow:"'demain à' p'",nextWeek:"eeee 'prochain à' p",other:"P"},i=(e,t,o,a)=>r[e];export{i as f};
//# sourceMappingURL=formatRelative-2SoUS26w.chunk.mjs.map
