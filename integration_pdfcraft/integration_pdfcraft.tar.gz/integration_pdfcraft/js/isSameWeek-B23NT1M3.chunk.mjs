import{n as a,s as t}from"./index-ClbE0eIr.chunk.mjs";function f(o,i,n){const[r,s]=a(n?.in,o,i);return+t(r,n)==+t(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-B23NT1M3.chunk.mjs.map
