import{n as a,s as o}from"./index-B7yr-g_1.chunk.mjs";function f(t,i,n){const[r,s]=a(n?.in,t,i);return+o(r,n)==+o(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-BhmwpUde.chunk.mjs.map
