import{n as a,s as o}from"./index-CuLswkLx.chunk.mjs";function f(t,r,n){const[i,s]=a(n?.in,t,r);return+o(i,n)==+o(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-DvFhYOeJ.chunk.mjs.map
