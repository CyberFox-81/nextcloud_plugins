import{n as a,s as t}from"./index-Dz9JTEn1.chunk.mjs";function f(i,o,n){const[r,s]=a(n?.in,i,o);return+t(r,n)==+t(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-Bc6e37W2.chunk.mjs.map
