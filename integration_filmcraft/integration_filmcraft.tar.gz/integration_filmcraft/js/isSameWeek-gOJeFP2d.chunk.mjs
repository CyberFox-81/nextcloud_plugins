import{n as a,s as t}from"./index-BI0yOO3q.chunk.mjs";function f(i,o,n){const[r,s]=a(n?.in,i,o);return+t(r,n)==+t(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-gOJeFP2d.chunk.mjs.map
