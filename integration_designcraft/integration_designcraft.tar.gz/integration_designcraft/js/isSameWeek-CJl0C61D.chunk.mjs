import{n as a,s as t}from"./index-C9nSIKYy.chunk.mjs";function f(i,o,n){const[s,r]=a(n?.in,i,o);return+t(s,n)==+t(r,n)}export{f as i};
//# sourceMappingURL=isSameWeek-CJl0C61D.chunk.mjs.map
