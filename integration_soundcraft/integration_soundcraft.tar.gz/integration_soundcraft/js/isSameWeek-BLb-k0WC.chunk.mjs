import{n as a,s as o}from"./index-BIZuByZh.chunk.mjs";function f(t,s,n){const[i,r]=a(n?.in,t,s);return+o(i,n)==+o(r,n)}export{f as i};
//# sourceMappingURL=isSameWeek-BLb-k0WC.chunk.mjs.map
