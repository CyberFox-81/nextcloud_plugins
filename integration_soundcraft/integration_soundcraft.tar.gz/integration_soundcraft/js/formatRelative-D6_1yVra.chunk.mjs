const r={lastWeek:"eeee 'dernier à' p",yesterday:"'hier à' p",today:"'aujourd’hui à' p",tomorrow:"'demain à' p'",nextWeek:"eeee 'prochain à' p",other:"P"},n=(e,o,t,a)=>r[e];export{n as f};
//# sourceMappingURL=formatRelative-D6_1yVra.chunk.mjs.map
