import{n as a,s as t}from"./index-DazVMQe_.chunk.mjs";function f(i,o,n){const[r,s]=a(n?.in,i,o);return+t(r,n)==+t(s,n)}export{f as i};
//# sourceMappingURL=isSameWeek-1z9a9Lte.chunk.mjs.map
